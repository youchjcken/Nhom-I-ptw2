<?php
/**
 * khai báo giá trị
 * themes_url = lấy đường dẫn của thư mục core
 */

define('THEME_URL', get_stylesheet_directory() );

define('CORE',THEME_URL."/core");

/**
 * @ NHung file /core/init.php
 */
require_once (CORE."/init.php");
/**
 * thiet lap cieu rong noi dung
 */
if(!isset($content_width)){
    $content_width = 620;
}
@ini_set('upload_max_size', '120M');
@ini_set('post_max_size', '120M');
@ini_set('max_execution_time', '300');
/**
 * khai bao chuc nang cuar theme
 */
if(!function_exists('trungcap_theme_setup')){
    function trungcap_theme_setup(){
        $language_folder = THEME_URL .'/languages';
        load_theme_textdomain('trungcap', $language_folder);
        /*tu dong them link vao head*/
        add_theme_support('automatic-feed-links');
        /*theme post thumbnail*/
        add_theme_support('post-thumbnails');
        /*theme post Format*/
        add_theme_support('post-formats', array(
            'image',
            'video',
            'gallery',
            'quote',
            'link'
        ));
        add_theme_support('title-tag');
        
        $default_background = array(
            'default-color' => '#e8e8e8'
        );
        add_theme_support('custom-background', $default_background);
        
        register_nav_menu('primary-menu', __('Primary Menu', 'trungcap'));
        
        $sidebar = array(
            'name' => __('Main Sidebar', 'trungcap'),
            'id' => 'main-sidebar',
            'description' => __('Default sidebar'),
            'class' => 'main-sidebar',
            'before_title'=> '<h3 class="widgettitle">',
            'after_title' =>'</h3>'
            
        );
        register_sidebar($sidebar);
        register_sidebar( array(
        'name' => __( 'Fourth Footer Widget Area', 'hrm' ),
        'id' => 'fourth-footer-widget-area',
        'description' => __( 'The fourth footer widget area', 'hrm' ),
        'before_widget' => '<div id="%1$s" class="widget-container %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
    }   
    add_action('init','trungcap_theme_setup');
    
}
/*-----
 * teamplate fun
 */
if(!function_exists('trungcap_header')){
    function trungcap_header(){?>
        <div class="site-name">
            <?php
                global $tp_options;
                if( $tp_options['logo-on'] == 0 ) :
            ?>
            <?php
                if(is_home()){
                    printf('<h1><a href="%1$s" title="%2$s">%3$s</a></h1>',
                    get_bloginfo('url'),
                    get_bloginfo('description'),
                    get_bloginfo('sitename'));
                } else {
                    printf('<h2><a href="%1$s" title="%2$s">%3$s</a></h2>',
                    get_bloginfo('url'),
                    get_bloginfo('description'),
                    get_bloginfo('sitename'));
                }
                
            ?>
            <?php
                                else :
                        ?>
                                <img src="<?php echo $tp_options['logo-image']['url']; ?>" />
                <?php endif; ?>
        </div>
<div class="site-description"><?php bloginfo('description');?></div><?php
    }
}
/**
 * thiet lap menu
 */
if(!function_exists('trungcap_menu')){
    function trungcap_menu($menu){
        $menu =array(
            'theme_location' => $menu,
            'container' => 'nav',
            'container_class' => $menu,
            'items_wrap' => '<ul id="%1$s" class="%2$s sf-menu">%3$s</ul1>'
        );
        wp_nav_menu($menu);
    }
}
/** phan trang
 
 */
if(!function_exists('trungcap_pagination')){
    function trungcap_pagination(){
        if($GLOBALS['wp_query']->max_num_pages < 2){
            return '';
        }?>
        <nav class="pagination" role="pavigation">
            <?php if (get_next_posts_link()) : ?>
            <div class="prev"><?php next_posts_link( __('Next...','trungcap'));?></div>
            <?php endif; ?>
            <?php if (get_previous_posts_link()) : ?>
            <div class="next"><?php previous_posts_link( __('...Prev','trungcap'));?></div>
            <?php endif; ?>
        </nav>
    <?php }
}
/** ham hien thij thumbnail
 * 
 */
if(!function_exists('trungcap_thumbnail')){
    function trungcap_thumbnail($size){
        if(!is_single() && has_post_thumbnail() && !post_password_required() || has_post_format('image')) : ?>
        <figure class="post-thumbnail"><?php the_post_thumbnail($size); ?></figure>
<?php endif; ?>
    <?php }
}
/**hien thi tieu de baif viet
 * 
 */
if(!function_exists('trungcap_entry_header')){
    function trungcap_entry_header(){?>
        <?php if (is_single()) :?>
        <h1 class="entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h1>
        <?php else : ?>
        <h2 class="entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
            <?php endif;?>
        <?php }
}
/**
 * laays du lieu post
 *
 */
if(!function_exists('trungcap_entry_meta()')){
    function trungcap_entry_meta(){?>
        <?php if (!is_page() ) : ?>
        <div class="entry-meta">
            <?php
                printf( __('<span class="author"> Posted by %1$s ', 'trungcap'),
                get_the_author());
                printf( __('<span class="date-published"> at %1$s ', 'trungcap'),
                get_the_date());
                printf( __('<span class="category"> in %1$s ' , 'trungcap'),
                get_the_category_list( ',' ));
                if(comments_open()):
                    echo '<span class="meta-reply">';
                    comments_popup_link(
                            __('Leave a comment ','trungcap'),
                            __('One comment', 'trungcap'),
                            __('%comments'),
                            __('Read all comments','trungcap')
                            );
                            echo '</span>';
                endif;
            ?>
        </div>
        <?php endif; ?>
    <?php }
}
/**
 * trungcap_entry_content = hien thi noi dung post
 */
if(!function_exists('trungcap_entry_content')){
    function trungcap_entry_content(){
        if(!is_single() && !is_page()){
            the_excerpt();
        } else {
            the_content();
            
            //phan trang trong post
            $link_pages =array(
                'before' => __('<p>Page: |', 'trungcap'),
                'after' => '</p>',
                'nextpagelink'=> __('Next Page', 'trungcap'),
                'previouspagelink' => __('Previous Page', 'trungcap')
            );
            wp_link_pages($link_pages);
        }
    }
}
function trungcap_readmore(){
    return '<a class="read-more" href="'.get_permalink(get_the_ID()). '">'. __('[...Read Morel]', 'trungcap').'</a>';
}
add_filter('excerpt_more', 'trungcap_readmore');

/** hien thi tag
 * 
 */
if (!function_exists('trungcap_entry_tag')){
    function trungcap_entry_tag(){
        if (has_tag()) :
            echo '<div class="entry-tag">';
            printf( __('Tagged in %1$s', 'trungcap'), get_the_tag_list('',','));
            echo '</div>';
            
        endif;
    }
}


/** 
 * nhung style.css
 */
function trungcap_style(){
    //md1
    wp_register_style('css1-style', get_template_directory_uri() . "./templates/module1/css/1.css",'all');
    wp_enqueue_style('css1-style');
  wp_register_style('font-style', get_template_directory_uri() . "./templates/module1/css/font-awesome.min.css",'all');
  wp_enqueue_style('font-style');


 //m9
 wp_register_style('css9-style', get_template_directory_uri() . "./templates/module9/css/9.css",'all');
 wp_enqueue_style('css9-style');
 wp_register_style('css2-style', get_template_directory_uri() . "./templates/module2/css/2.css",'all');
 wp_register_style('bookstrap-css', get_template_directory_uri() . "./bootstrap.min.css",'all');
 wp_enqueue_style('bookstrap-css');
 wp_enqueue_style('css2-style');
 wp_register_style('book-style', get_template_directory_uri() . "./templates/module1/css/bootstrap.min.css",'all');
 wp_enqueue_style('book-style');
 wp_register_style('font-style', get_template_directory_uri() . "./templates/module1/css/font-awesome.min.css",'all');
 wp_enqueue_style('font-style');




 wp_register_style('font-awesome', get_template_directory_uri() . "./font-awesome.min.css",'all');
 wp_enqueue_style('font-awesome');
 wp_register_style('bookstrap-css', get_template_directory_uri() . "./bootstrap.min.css",'all');
 wp_enqueue_style('bookstrap-css');
 wp_register_style('javascipt-js', get_template_directory_uri() . "./javascript.js",'all');
 wp_enqueue_style('javascipt-js');
 wp_register_style('jquery', get_template_directory_uri() . "./jquery-2.1.4.min.js",'all');
 wp_enqueue_style('jquery-js');
 wp_register_script('javascipt-js', get_template_directory_uri() . "./javascript.js",'all');
 wp_enqueue_script('javascipt-js');
 
 //module5
  wp_register_style('css5-style', get_template_directory_uri() . "./templates/module5/css/5.css",'all');
 wp_enqueue_style('css5-style');
 //module10
 wp_register_style('css10-style', get_template_directory_uri() . "./templates/module10/css/10.css",'all');
 wp_enqueue_style('css10-style');
 wp_register_style('swiper', get_template_directory_uri() . "./templates/module10/css/swiper.min.css",'all');
 wp_enqueue_style('swiper');
 // wp_register_script('bot-script', get_template_directory_uri() ."./templates/module10/js/swiper.min.js", array('jquery'));
 // wp_enqueue_script('bot-script');
 // wp_register_script('scrip-js', get_template_directory_uri() ."./templates/module10/js/10.js", array('jquery'));
 // wp_enqueue_script('scrip-js');
 //module27
 wp_register_style('css27-style', get_template_directory_uri() . "./templates/module27/css/27.css",'all');
 wp_enqueue_style('css27-style');
 //module 11
  wp_register_script('modul-11', get_template_directory_uri() ."./css/hinh13.js", array('jquery'));
 wp_enqueue_script('modul-11');
 wp_register_script('modul1-11', get_template_directory_uri() ."./css/jquery-2.1.4.min_1.js", array('jquery'));
 wp_enqueue_script('modul1-11');
 

  //
  
 // //module3
 wp_register_style('css3-style', get_template_directory_uri() . "./templates/module3/css/3.css",'all');
 wp_enqueue_style('css3-style');
 //module4
 wp_register_style('css4-style', get_template_directory_uri() . "./templates/module4/css/4.css",'all');
 wp_enqueue_style('css4-style');
 //module8
 wp_register_style('css8-style', get_template_directory_uri() . "./templates/module8/css/8.css",'all');
 wp_enqueue_style('css8-style');
 wp_register_script('8-js', get_template_directory_uri() ."./templates/module8/js/8.js", array('jquery'));
 wp_enqueue_script('8-js');

//module6
wp_register_style('css6-style', get_template_directory_uri() . "./templates/module6/css/6.css",'all');
wp_enqueue_style('css6-style');
wp_register_style('css6-swiper', get_template_directory_uri() . "./templates/module6/css/swiper.css",'all');
wp_enqueue_style('css6-swiper');
wp_register_style('booktrap-6', get_template_directory_uri() . "./templates/module6/css/bootstrap.min.css",'all');
wp_enqueue_style('booktrap-6');
//  wp_register_style('booktrap-theme', get_template_directory_uri() . "./templates/module6/css/bootstrap-theme.min.css",'all');
//  wp_enqueue_style('booktrap-theme');
//  wp_register_script('js-6', get_template_directory_uri() ."./templates/module6/js/6.js", array('jquery'));
//   wp_enqueue_script('js-6');
 wp_register_script('swiper-6', get_template_directory_uri() ."./templates/module6/js/swiper.js", array('jquery'));
 wp_enqueue_script('swiper-6');
//module4
wp_register_style('css4-style', get_template_directory_uri() . "./templates/module4/css/4.css",'all');
wp_enqueue_style('css4-style');
wp_register_style('css4-swiper', get_template_directory_uri() . "./templates/module4/css/swiper.css",'all');
wp_enqueue_style('css4-swiper');

wp_register_script('js-26', get_template_directory_uri() ."./css/26.js", array('jquery'));
 wp_enqueue_script('js-26');


    /*wp_register_style('main-style', get_template_directory_uri() . "/style.css", 'all');
    wp_enqueue_style('main-style');
    wp_register_style('reset-style', get_template_directory_uri() . "/reset.css", 'all');
    wp_enqueue_style('reset-style');*/
    wp_register_style('7-style', get_template_directory_uri() . "/css/7.css", 'all');
    wp_enqueue_style('7-style');
    wp_register_style('2-style', get_template_directory_uri() . "/css/2.css", 'all');
    wp_enqueue_style('2-style');
    wp_register_style('9-style', get_template_directory_uri() . "/css/9.css", 'all');
    wp_enqueue_style('9-style');
    wp_register_style('8-style', get_template_directory_uri() . "/css/8.css", 'all');
    wp_enqueue_style('8-style');
    // wp_register_style('1-style', get_template_directory_uri() . "/css/1.css", 'all');
    // wp_enqueue_style('1-style');
    wp_register_style('4-style', get_template_directory_uri() . "/css/4.css", 'all');
    wp_enqueue_style('4-style');
    wp_register_style('266-style', get_template_directory_uri() . "/css/26_1.css", 'all');
    wp_enqueue_style('266-style');
    wp_register_style('10-style', get_template_directory_uri() . "/css/10.css", 'all');
    wp_enqueue_style('10-style');
    wp_register_style('11-style', get_template_directory_uri() . "/css/11.css", 'all');
    wp_enqueue_style('11-style');
    wp_register_style('12-style', get_template_directory_uri() . "/css/12.css", 'all');
    wp_enqueue_style('12-style');
    wp_register_style('13-style', get_template_directory_uri() . "/css/13.css", 'all');
    wp_enqueue_style('13-style');
    wp_register_style('14-style', get_template_directory_uri() . "/css/14.css", 'all');
    wp_enqueue_style('14-style');
    wp_register_style('15-style', get_template_directory_uri() . "/css/15.css", 'all');
    wp_enqueue_style('15-style');
    wp_register_style('17-style', get_template_directory_uri() . "/css/17.css", 'all');
    wp_enqueue_style('17-style');
    wp_register_style('18-style', get_template_directory_uri() . "/css/18-19-20-21.css", 'all');
    wp_enqueue_style('18-style');
    wp_register_style('22-style', get_template_directory_uri() . "/css/22.css", 'all');
    wp_enqueue_style('22-style');
    wp_register_style('23-style', get_template_directory_uri() . "/css/23.css", 'all');
    wp_enqueue_style('23-style');
    wp_register_style('26-style', get_template_directory_uri() . "/css/26.css", 'all');
    wp_enqueue_style('26-style');
    //
    wp_register_style('bootstrap-style', get_template_directory_uri() . "/css/bootstrap.min.css", 'all');
    wp_enqueue_style('bootstrap-style');
    wp_register_style('font-style', get_template_directory_uri() . "/css/font-awesome.min.css", 'all');
    wp_enqueue_style('font-style');
    wp_register_style('sw-style', get_template_directory_uri() . "/css/swiper.min.css", 'all');
    wp_enqueue_style('sw-style');
    wp_register_style('sw1-style', get_template_directory_uri() . "/css/6/swiper.min.css", 'all');
    wp_enqueue_style('sw1-style');
    
    /*wp_register_script('custom-script', get_template_directory_uri() ."/custom.js", array('jquery'));
    wp_enqueue_script('custom-script');*/
    wp_register_script('boo-script', get_template_directory_uri() ."/css/bootstrap.min.js", array('jquery'));
    wp_enqueue_script('boo-script');
    wp_register_script('jav-script', get_template_directory_uri() ."/css/javascript.js", array('jquery'));
    wp_enqueue_script('jav-script');
    wp_register_script('jque-script', get_template_directory_uri() ."/css/jquery-2.1.4.min.js", array('jquery'));
    wp_enqueue_script('jque-script');
    wp_register_script('scip-script', get_template_directory_uri() ."/css/scripts.js", array('jquery'));
    wp_enqueue_script('scip-script');
    wp_register_script('swiper-script', get_template_directory_uri() ."/css/swiper.min.js", array('jquery'));
    wp_enqueue_script('swiper-script');
    wp_register_script('swiper1-script', get_template_directory_uri() ."/css/6/swiper.min.js", array('jquery'));
    wp_enqueue_script('swiper1-script');
    
    
}
add_action('wp_enqueue_scripts', 'trungcap_style');


add_filter( 'gettext', function ( $strings ) {
/**
* Holding translations/changes.
'to translate' => 'the translation or rewording'
*/
$text = array(
'QUICK VIEW' => 'Xem nhanh',

'FILTER' => 'Bộ Lọc',
'Price' => 'Giá',
'CATEGORY ARCHIVES' =>'Danh mục',
'This entry was posted in' => 'Bài này đã được đăng',
'Posted in'=>'Đăng trong',
'Leave a comment'=>'Để lại bình luận',
'Continue reading '=>'Xem thêm',
'POSTED ON'=> 'Đăng trên',
'admin'=>'Quốc Đạt',
'Lựa chọn các tùy chọn' => 'Mua hàng',
' by '=>'bởi',
'Bookmark the'=>'Đánh dấu trang',

);
$strings = str_ireplace( array_keys( $text ), $text, $strings );
return $strings;
}, 20 );
// Add custom Theme Functions here
function hrm_widgets_init() {
    // First footer widget area.
    register_sidebar( array(
        'name' => __( 'First Footer Widget Area', 'hrm' ),
        'id' => 'first-footer-widget-area',
        'description' => __( 'The first footer widget area', 'hrm' ),
        'before_widget' => '<div id="%1$s" class="widget-container %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
 
    // Second Footer Widget Area.
    register_sidebar( array(
        'name' => __( 'Second Footer Widget Area', 'hrm' ),
        'id' => 'second-footer-widget-area',
        'description' => __( 'The second footer widget area', 'hrm' ),
        'before_widget' => '<div id="%1$s" class="widget-container %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
 
    // Third Footer Widget Area, located in the footer. Empty by default.
    register_sidebar( array(
        'name' => __( 'Third Footer Widget Area', 'hrm' ),
        'id' => 'third-footer-widget-area',
        'description' => __( 'The third footer widget area', 'hrm' ),
        'before_widget' => '<div id="%1$s" class="widget-container %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
 
    // Fourth Footer Widget Area, located in the footer. Empty by default.
    
        
}
add_action( 'widgets_init', 'hrm_widgets_init' );

