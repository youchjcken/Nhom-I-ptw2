<!DOCTYPE html>
<html <?php language_attributes();?>>
<head>
    <meta charset="<?php bloginfo('charset');?>"/>
    <link rel="profile" href="http://gmgp.org/xfn/11"/>
    
    <link rel="pingback" href="<?php bloginfo('pingback_url');?>"/>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <div id="container">
    <div class="logo">
        
        <?php get_template_part( 'templates/module1/1-content' ); ?> 
        <?php get_template_part('modul/10','content') ?>;
        
        
    </div>
        