
<?php get_header(); ?>
    

<?php get_template_part( 'templates/module2/2-content' ); ?> 
<?php get_template_part('modul/26','content4') ?>
<?php get_template_part( 'templates/module3/3-content' ); ?> 
<?php get_template_part( 'templates/module9/9-content' ); ?> 
<?php get_template_part( 'templates/module5/5-content' ); ?> 
<?php get_template_part( 'templates/module8/8-content' ); ?> 
<?php get_template_part( 'templates/module27/27-content' ); ?> 
        

<?php get_footer();?>