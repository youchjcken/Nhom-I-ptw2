
<?php get_header(); ?>
    
<?php get_template_part( 'templates/module10/10-content' ); ?> 
<?php get_template_part( 'templates/module2/2-content' ); ?> 
<!--<?php echo do_shortcode(''); ?>-->
<div id="aaaaaa" class="container">
    <div class="row">
        <ul class="nav nav-tabs">
  	<li class="nav-item">
    	<a class="nav-link active" data-toggle="tab" href="#home">Tất cả</a>
  	</li>
  	<?php $args = array( 
	    'hide_empty' => 0,
	    'taxonomy' => 'product_cat',
	    'parent' => 0
	    ); 
	    $cates = get_categories( $args ); 
	    foreach ( $cates as $cate ) {  ?>
			<li class="nav-item">
			    <a class="nav-link" data-toggle="tab" href="#<?php echo $cate->slug; ?>"><?php echo $cate->name; ?></a>
			</li>
	<?php } ?>
</ul>
<div class="tab-content">
	<div class="tab-pane container active" id="home">
		<?php
			$args = array( 
				'post_type' => 'product',
				'posts_per_page' => 8 
			); 
		?>
		<?php $getposts = new WP_query( $args);?>
		<?php global $wp_query; $wp_query->in_the_loop = true; ?>
		<?php while ($getposts->have_posts()) : $getposts->the_post(); ?>
		<?php global $product; ?>
			<div class="item-product1">
				<a href="<?php the_permalink(); ?>">
					<?php echo get_the_post_thumbnail(get_the_ID(), 'thumnail', array( 'class' =>'thumnail') ); ?>
				</a>
				<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
				<div class="price-product"><?php echo $product->get_price_html(); ?></div>
				<a href="<?php bloginfo('url'); ?>?add-to-cart=<?php the_ID(); ?>">Thêm vào giỏ</a>
			</div>
		<?php endwhile; wp_reset_postdata();?>
	</div>
  	<?php $args = array( 
	    'hide_empty' => 0,
	    'taxonomy' => 'product_cat',
	    'parent' => 0
	    ); 
	    $cates = get_categories( $args ); 
	    foreach ( $cates as $cate ) {  ?>
			<div class="tab-pane container fade" id="<?php echo $cate->slug; ?>">
				<?php
					$args = array( 
						'post_type' => 'product',
						'posts_per_page' => 8,
						'product_cat' => $cate->slug
					); 
				?>
				<?php $getposts = new WP_query( $args);?>
				<?php global $wp_query; $wp_query->in_the_loop = true; ?>
				<?php while ($getposts->have_posts()) : $getposts->the_post(); ?>
				<?php global $product; ?>
					<div class="item-product1">
						<a href="<?php the_permalink(); ?>">
							<?php echo get_the_post_thumbnail(get_the_ID(), 'thumnail', array( 'class' =>'thumnail') ); ?>
						</a>
						<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
						<div class="price-product"><?php echo $product->get_price_html(); ?></div>
						<a href="<?php bloginfo('url'); ?>?add-to-cart=<?php the_ID(); ?>">Thêm vào giỏ</a>
					</div>
				<?php endwhile; wp_reset_postdata();?>
			</div>
	<?php } ?>
  	
</div>
    </div>
</div>	

<?php get_template_part( 'templates/module3/3-content' ); ?> 
<div class="produc1">
    <div class="container">
        <div class="row">
            <div class="titlee"><h4>Music, Movies & Video Games
</h4></div>
            <div class="col-md-4">
                
                <?php
	$cat = 'iphone';
	$args = array( 
		'post_type' => 'product',
		'posts_per_page' => 10, 
		'product_cat' => $cat
	); 
?>
<?php $getposts = new WP_query( $args);?>
<?php global $wp_query; $wp_query->in_the_loop = true; ?>
<?php while ($getposts->have_posts()) : $getposts->the_post(); ?>
<?php global $product; ?>

	<div class="item-product">
		<a href="<?php the_permalink(); ?>">
			<?php echo get_the_post_thumbnail(get_the_ID(), 'thumnail1', array( 'class' =>'thumnail1') ); ?>
		</a>
            <div class="suba">
                <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
		<div class="price-product"><?php echo $product->get_price_html(); ?></div>
		<a href="<?php bloginfo('url'); ?>?add-to-cart=<?php the_ID(); ?>">Thêm vào giỏ</a>
            </div>
		
	</div>
    
<?php endwhile; wp_reset_postdata();?>
            </div>
            <div class="col-md-4">
                <div class="titlee"><h4></h4></div>
                <?php
	$cat = 'iphone';
	$args = array( 
		'post_type' => 'product',
		'posts_per_page' => 10, 
		'product_cat' => $cat
	); 
?>
<?php $getposts = new WP_query( $args);?>
<?php global $wp_query; $wp_query->in_the_loop = true; ?>
<?php while ($getposts->have_posts()) : $getposts->the_post(); ?>
<?php global $product; ?>

	<div class="item-product">
		<a href="<?php the_permalink(); ?>">
			<?php echo get_the_post_thumbnail(get_the_ID(), 'thumnail1', array( 'class' =>'thumnail1') ); ?>
		</a>
		<div class="suba">
                <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
		<div class="price-product"><?php echo $product->get_price_html(); ?></div>
		<a href="<?php bloginfo('url'); ?>?add-to-cart=<?php the_ID(); ?>">Thêm vào giỏ</a>
            </div>
	</div>
    
<?php endwhile; wp_reset_postdata();?>
            </div>
            <div class="col-md-4">
                <div class="titlee"><h4></h4></div>
                <?php
	$cat = 'iphone';
	$args = array( 
		'post_type' => 'product',
		'posts_per_page' => 10, 
		'product_cat' => $cat
	); 
?>
<?php $getposts = new WP_query( $args);?>
<?php global $wp_query; $wp_query->in_the_loop = true; ?>
<?php while ($getposts->have_posts()) : $getposts->the_post(); ?>
<?php global $product; ?>

	<div class="item-product">
		<a href="<?php the_permalink(); ?>">
			<?php echo get_the_post_thumbnail(get_the_ID(), 'thumnail1', array( 'class' =>'thumnail1') ); ?>
		</a>
		<div class="suba">
                <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
		<div class="price-product"><?php echo $product->get_price_html(); ?></div>
		<a href="<?php bloginfo('url'); ?>?add-to-cart=<?php the_ID(); ?>">Thêm vào giỏ</a>
            </div>
	</div>
    
<?php endwhile; wp_reset_postdata();?>
            </div>
        </div>
    </div>
</div>

<?php get_template_part( 'templates/module5/5-content' ); ?> 
<?php get_template_part( 'templates/module8/8-content' ); ?> 
<div class="produc">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="titlee"><h4>Hot New Releases</h4></div>
                <?php
	$cat = 'iphone';
	$args = array( 
		'post_type' => 'product',
		'posts_per_page' => 10, 
		'product_cat' => $cat
	); 
?>
<?php $getposts = new WP_query( $args);?>
<?php global $wp_query; $wp_query->in_the_loop = true; ?>
<?php while ($getposts->have_posts()) : $getposts->the_post(); ?>
<?php global $product; ?>

	<div class="item-product">
		<a href="<?php the_permalink(); ?>">
			<?php echo get_the_post_thumbnail(get_the_ID(), 'thumnail1', array( 'class' =>'thumnail1') ); ?>
		</a>
            <div class="suba">
                <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
		<div class="price-product"><?php echo $product->get_price_html(); ?></div>
		<a href="<?php bloginfo('url'); ?>?add-to-cart=<?php the_ID(); ?>">Thêm vào giỏ</a>
            </div>
		
	</div>
    
<?php endwhile; wp_reset_postdata();?>
            </div>
            <div class="col-md-4">
                <div class="titlee"><h4>Top Selling Products</h4></div>
                <?php
	$cat = 'iphone';
	$args = array( 
		'post_type' => 'product',
		'posts_per_page' => 10, 
		'product_cat' => $cat
	); 
?>
<?php $getposts = new WP_query( $args);?>
<?php global $wp_query; $wp_query->in_the_loop = true; ?>
<?php while ($getposts->have_posts()) : $getposts->the_post(); ?>
<?php global $product; ?>

	<div class="item-product">
		<a href="<?php the_permalink(); ?>">
			<?php echo get_the_post_thumbnail(get_the_ID(), 'thumnail1', array( 'class' =>'thumnail1') ); ?>
		</a>
		<div class="suba">
                <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
		<div class="price-product"><?php echo $product->get_price_html(); ?></div>
		<a href="<?php bloginfo('url'); ?>?add-to-cart=<?php the_ID(); ?>">Thêm vào giỏ</a>
            </div>
	</div>
    
<?php endwhile; wp_reset_postdata();?>
            </div>
            <div class="col-md-4">
                <div class="titlee"><h4>Featured Products</h4></div>
                <?php
	$cat = 'iphone';
	$args = array( 
		'post_type' => 'product',
		'posts_per_page' => 10, 
		'product_cat' => $cat
	); 
?>
<?php $getposts = new WP_query( $args);?>
<?php global $wp_query; $wp_query->in_the_loop = true; ?>
<?php while ($getposts->have_posts()) : $getposts->the_post(); ?>
<?php global $product; ?>

	<div class="item-product">
		<a href="<?php the_permalink(); ?>">
			<?php echo get_the_post_thumbnail(get_the_ID(), 'thumnail1', array( 'class' =>'thumnail1') ); ?>
		</a>
		<div class="suba">
                <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
		<div class="price-product"><?php echo $product->get_price_html(); ?></div>
		<a href="<?php bloginfo('url'); ?>?add-to-cart=<?php the_ID(); ?>">Thêm vào giỏ</a>
            </div>
	</div>
    
<?php endwhile; wp_reset_postdata();?>
            </div>
        </div>
    </div>
</div>

 
        

<?php get_footer();?>