<div class="type-11">
    
        <div class="row">
            


            <nav id="fixNav" class="aaa">
                <?php wp_nav_menu( 
  array( 
      'theme_location' => 'primary-menu', 
      'container' => 'false', 
      'menu_id' => 'header-menu', 
      'menu_class' => 'menu'
   ) 
); ?>
          </nav>
            
  
        </div>
    
</div>