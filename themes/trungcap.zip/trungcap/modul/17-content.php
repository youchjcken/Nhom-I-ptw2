<?php
$url_host = $_SERVER['HTTP_HOST'];

$pattern_document_root = addcslashes(realpath($_SERVER['DOCUMENT_ROOT']), '\\');

$pattern_uri = '/' . $pattern_document_root . '(.*)$/';

preg_match_all($pattern_uri, __DIR__, $matches);

$url_path = $url_host . $matches[1][0];

$url_path = str_replace('\\', '/', $url_path);
?>
<div class="type-17" style="background-image: url(<?php echo(get_template_directory_uri()); ?>/images/17/17.jpg);">
    <div class="container">
      <div class="mkd-title-holder">
        <div class="grid">
          <h1 class="title">Shop</h1>
        </div>
      </div>
    </div>
</div>
