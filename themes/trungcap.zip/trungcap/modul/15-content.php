
<div class="type-15">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="thin" >
                    <div class="categories">
                        <div class="title-holder">
                            <h4 class="title">Category</h4>
                        </div>
                        <ul class="product">
                            <li class="item"><a href="#">Android</a></li>
                            <li class="item "> <a href="#">Books&amp;Audio</a></li>
                            <li class="item "><a href="#">Cameras&amp;Video</a></li>
                            <li class="item "><a href="#">Computers</a></li>
                            <li class="item "><a href="#">Electronics</a></li>
                            <li class="item "><a href="#">Gadgets</a></li>
                            <li class="item "><a href="#">Headphones</a></li>
                            <li class="item "><a href="#">Home Appliances</a></li>
                            <li class="item "><a href="#">iPhone</a></li>
                            <li class="item "><a href="#">Laptop &amp; Tablet</a></li>
                            <li class="item "><a href="#">Movies</a></li>
                            <li class="item "><a href="#">Multimedia</a></li>
                            <li class="item "><a href="#">Music&amp;Videos</a></li>
                            <li class="item "><a href="#">Office</a></li>
                            <li class="item "><a href="#">Phones</a></li>
                            <li class="item "><a href="#">Products</a></li>
                            <li class="item "><a href="#">Smartphone</a></li>
                            <li class="item "><a href="#">Technology</a></li>
                        </ul>
                    </div>
                    <div class="layered">
                        <div class="holder">
                            <h4 class="title">Color</h4>
                        </div>
                        <ul class="product-team">
                            <li class="nav-team ">
                                <a href="#">Black</a>
                                <span class="team">(1)</span>
                            </li>
                            <li class="nav-team ">
                                <a href="#">Gold</a>
                                <span class="team">(1)</span>
                            </li>
                            <li class="nav-team ">
                                <a href="#">Olive</a>
                                <span class="team">(1)</span></li>
                            <li class="nav-team "><a href="#">Rose</a>
                                <span class="team">(1)</span>
                            </li><li class="nav-team ">
                                <a href="#">Silver</a>
                                <span class="team">(1)</span>
                            </li>
                        </ul>
                    </div>
                    <div class="price1">
                        <div class="title-holder">
                            <h4 class="title">Price</h4>
                            <div data-role="main" class="ui-content">
                                <div class="dd">
                                    <form method="post" action="/action_page_post.php">
                                        <div data-role="rangeslider" class="hh">
                                            <input type="range" name="price-min" id="price-min" value="200" min="0" max="800">
                                        </div>
                                        <div class="label">
                                            Price:  <span class="from">$9</span> — <span class="to">$1,899</span>
                                        </div>
                                    </form>
                                </div>
                                <button type="submit" class="button">Filter</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="row">
                <div class="col-md-6" >
                    <div class="title">
                        <h5> Showing 1–12 of 57 results</h5>
                    </div>
                </div>
                <div class="col-md-6" >
                    <div class="dropdown">
                        <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Default sorting
                            <span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li><a href="#about">Default sorting</a></li>
                            <li> <a href="#base">Sort by popularty</a></li>
                            <li> <a href="#blog">Sort by average rating</a></li>
                            <li> <a href="#contact">Sort by newess</a></li>
                            <li> <a href="#custom">Sort by pice: low to</a></li>
                            <li> <a href="#support">Sort by pice :high to low</a></li> 
                        </ul>
                    </div>
                </div>
                </div>
            <div class="product-item">
                <div class="row">
                    <div class="col-md-4 col-sm-6">
                        <div class="thumbnails">
                            <div class="woocommerce">
                    <ul class="products">
                                        <?php
                        $getproduct = new WP_Query(array(
                        'post_type'=>'product',
                        'post_status'=>'publish',
                        'tax_query' => array(
                        array(
                            'taxonomy' => 'product_cat',
                            'field' => 'id',
                            'terms' =>  17
                        )
                        ),
                        'orderby' => 'ID',
                        'order' => 'DESC',
                        'posts_per_page'=> $instance['content'],
                        'paged' => 1,
                    ));

       ?>
                        
                            <?php while ($getproduct->have_posts()) : $getproduct->the_post(); ?>
                                    <?php   woocommerce_get_template_part( 'content', 'product' );   ?>
                        <?php endwhile ;
        // wp_reset_query() ; 
        wp_reset_postdata();
        ?>
            
    </ul><!--/.products-->
	</div> 
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="thumbnails">
                            <div class="comporter">
                                <div class="category">
                                    <a href="#">Laptop &amp; Tablet</a>
                                </div>
                                <div class="compare">
                                    <span><a href="#"><i class="fa fa-list" aria-hidden="true"></i></a></span>
                                    <span><a href="#"><i class="fa fa-heart-o" aria-hidden="true"></i></a></span>
                                </div>
                            </div>
                            <div class="hinh12">
                                <img src="http://localhost:8080/projectptw2/wordpress/wp-content/themes/trungcap/images/15/1.jpg" width="525px;" height="532px;" alt="" class="img-responsive">
                            </div>
                            <div class="price-w">
                                <div class="stars">
                                    <form action="star">
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                    </form>
                                </div>
                                <div class="word">
                                    <h5>
                                        <a href="#">Apple MacBook Pro With Touch Bar MF841DSN/A 13″</a>
                                    </h5>
                                </div>
                                <div class="price">
                                    <span>$999</span>
                                </div>
                                <div class="icon">
                                    <a href="#"><i class="fa fa-cart-plus" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div id="hh" class="thumbnails">
                            <div class="comporter">
                                <div class="category">
                                    <a href="#">Laptop &amp; Tablet</a>
                                </div>
                                <div class="compare">
                                    <span><a href="#"><i class="fa fa-list" aria-hidden="true"></i></a></span>
                                    <span><a href="#"><i class="fa fa-heart-o" aria-hidden="true"></i></a></span>
                                </div>
                            </div>
                            <div class="hinh12">
                                <img src="http://localhost:8080/projectptw2/wordpress/wp-content/themes/trungcap/images/15/6.jpg" width="525px;" height="532px;" alt="" class="img-responsive">
                            </div>
                            <div class="hh">
                                <span class="product12">NEW</span>
                            </div>
                            <div class="price-w">
                                <div class="stat">
                                    <div class="stars">
                                        <form action="star">
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        </form>
                                    </div>
                                </div>
                                <div class="word">
                                    <h5>
                                        <a href="#">MacBook Rose Gold 1.2GHz 256GB butterfly mechanism</a>
                                    </h5>
                                </div>
                                <div class="price">
                                    <span>$1,299</span>
                                </div>
                                <div class="icon">
                                    <a href="#"><i class="fa fa-cart-plus" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="thumbnails">
                            <div class="comporter">
                                <div class="category">
                                    <a href="#">Home Appliances</a>
                                </div>
                                <div class="compare">
                                    <span><a href="#"><i class="fa fa-list" aria-hidden="true"></i></a></span>
                                    <span><a href="#"><i class="fa fa-heart-o" aria-hidden="true"></i></a></span>
                                </div>
                            </div>
                            <div class="hinh12">
                                <div class="hinhkk">
                                    <img src="http://localhost:8080/projectptw2/wordpress/wp-content/themes/trungcap/images/15/7.jpg" width="525px;" height="532px;" alt="" class="img-responsive">
                                </div>
                            </div>
                            <div class="bb">  <span class="stock">Out of Stock</span></div>
                            <div class="price-w">
                                <div class="stars">
                                    <form action="star">
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                    </form>
                                </div>
                                <div class="word">
                                    <h5>
                                        <a href="#">TCL 32S305 32-Inch 720p Roku Smart LED TV</a>
                                    </h5>
                                </div>
                                <div class="price">
                                    <span>$675</span>
                                </div>
                                <div class="iconn">
                                    <div class="contai">
                                        <a href="#"><i class="fa fa-times-circle-o" aria-hidden="true"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="thumbnails">
                            <div class="comporter">
                                <div class="category">
                                    <a href="#">Phone</a>
                                </div>
                                <div class="compare">
                                    <span><a href="#"><i class="fa fa-list" aria-hidden="true"></i></a></span>
                                    <span><a href="#"><i class="fa fa-heart-o" aria-hidden="true"></i></a></span>
                                </div>
                            </div>
                            <div class="hinh12">
                                <img src="http://localhost:8080/projectptw2/wordpress/wp-content/themes/trungcap/images/15/8.jpg" width="525px;" height="532px;" alt="" class="img-responsive">
                            </div>
                            <div class="price-w">
                                <div class="stars">
                                    <form action="star">
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                    </form>
                                </div>
                                <div class="word">
                                    <h5>
                                        <a href="#">Apple iPhone 7 4.7-Inch Silver 128GB Contact-Free</a>
                                    </h5>
                                </div>
                                <div class="price">
                                    <span>$749</span>
                                </div>
                                <div class="icon">
                                    <a href="#"><i class="fa fa-cart-plus" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div id="hh" class="thumbnails">
                            <div class="comporter">
                                <div class="category">
                                    <a href="#">Home Appliances</a>
                                </div>
                                <div class="compare">
                                    <span><a href="#"><i class="fa fa-list" aria-hidden="true"></i></a></span>
                                    <span><a href="#"><i class="fa fa-heart-o" aria-hidden="true"></i></a></span>
                                </div>
                            </div>
                            <div class="hinh12">
                                <img src="http://localhost:8080/projectptw2/wordpress/wp-content/themes/trungcap/images/15/9.jpg" width="525px;" height="532px;" alt="" class="img-responsive">
                            </div>
                            <div class="price-w">
                                <div class="stat">
                                    <div class="stars">
                                        <form action="star">
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        </form>
                                    </div>
                                </div>
                                <div class="word">
                                    <h5>
                                        <a href="#">ES62-T Steam Iron with Nonstick Soleplate</a>
                                    </h5>
                                </div>
                                <div class="price">
                                    <span>$59</span>
                                </div>
                                <div class="icon">
                                    <a href="#"><i class="fa fa-cart-plus" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="thumbnails">
                            <div class="comporter">
                                <div class="category">
                                    <a href="#">Home Appliances</a>
                                </div>
                                <div class="compare">
                                    <span><a href="#"><i class="fa fa-list" aria-hidden="true"></i></a></span>
                                    <span><a href="#"><i class="fa fa-heart-o" aria-hidden="true"></i></a></span>
                                </div>
                            </div>
                            <div class="hinh12">
                                <img src="http://localhost:8080/projectptw2/wordpress/wp-content/themes/trungcap/images/15/10.jpg" width="525px;" height="532px;" alt="" class="img-responsive">
                            </div>
                            <div class="price-w">
                                <div class="stat">
                                    <div class="stars">
                                        <form action="star">
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        </form>
                                    </div>
                                </div>
                                <div class="word">
                                    <h5>
                                        <a href="#">Ninja Master Prep Pro Food and Drink Mixer</a>
                                    </h5>
                                </div>
                                <div class="price">
                                    <span>$99</span>
                                </div>
                                <div class="icon">
                                    <a href="#"><i class="fa fa-cart-plus" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="thumbnails">
                            <div class="comporter">
                                <div class="category">
                                    <a href="#">Laptop &amp; Tablet</a>
                                </div>
                                <div class="compare">
                                    <span><a href="#"><i class="fa fa-list" aria-hidden="true"></i></a></span>
                                    <span><a href="#"><i class="fa fa-heart-o" aria-hidden="true"></i></a></span>
                                </div>
                            </div>
                            <div class="hinh12">
                                <img src="http://localhost:8080/projectptw2/wordpress/wp-content/themes/trungcap/images/15/11.jpg" width="525px;" height="532px;" alt="" class="img-responsive">
                            </div>
                            <div class="price-w">
                                <div class="stat">
                                    <div class="stars">
                                        <form action="star">
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        </form>
                                    </div>
                                </div>
                                <div class="word">
                                    <h5>
                                        <a href="#">Apple iPad 9.7 (2017) 128GB WiFi WLAN iOS tablet″</a>
                                    </h5>
                                </div>
                                <div class="price">
                                    <span>$999</span>
                                </div>
                                <div class="icon">
                                    <a href="#"><i class="fa fa-cart-plus" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div id="hh" class="thumbnails">
                            <div class="comporter">
                                <div class="category">
                                    <a href="#">Laptop &amp; Tablet</a>
                                </div>
                                <div class="compare">
                                    <span><a href="#"><i class="fa fa-list" aria-hidden="true"></i></a></span>
                                    <span><a href="#"><i class="fa fa-heart-o" aria-hidden="true"></i></a></span>
                                </div>
                            </div>
                            <div class="hinh12">
                                <img src="http://localhost:8080/projectptw2/wordpress/wp-content/themes/trungcap/images/15/12.jpg" width="525px;" height="532px;" alt="" class="img-responsive">
                            </div>
                            <div class="price-w">
                                <div class="stat">
                                    <div class="stars">
                                        <form action="star">
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        </form>
                                    </div>
                                </div>
                                <div class="word">
                                    <h5>
                                        <a href="#">Apple In-Ear Headphones with Remote and Mic</a>
                                    </h5>
                                </div>
                                <div class="price">
                                    <span>$65</span>
                                </div>
                                <div class="icon">
                                    <a href="#"><i class="fa fa-cart-plus" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="pagination">
                    <a href="#">&laquo;</a>
                    <a href="#">1</a>
                    <a href="#" >2</a>
                    <a href="#">3</a>
                    <a href="#">4</a>
                    <a href="#">5</a>
                    <a href="#">6</a>
                    <a href="#">&raquo;</a>
                </div>
            </div>
        </div>
        </div>                  
    </div>   
</div>
