<?php
$url_host = $_SERVER['HTTP_HOST'];

$pattern_document_root = addcslashes(realpath($_SERVER['DOCUMENT_ROOT']), '\\');

$pattern_uri = '/' . $pattern_document_root . '(.*)$/';

preg_match_all($pattern_uri, __DIR__, $matches);

$url_path = $url_host . $matches[1][0];

$url_path = str_replace('\\', '/', $url_path);
?>

<div class="type-3">
    <div class="container">
        <div class="row">
            <div class="post-content1">
                <div class="col-md-2">
                    <div class="information">
                        <div class="img1">
                            <a href="#"><img id="author-icon" src="<?php echo(get_template_directory_uri()); ?>/images/18-19-20-21/19.1.jpeg"></a>
                        </div>
                        <a href="#">Maria Keller</a>
                        <span>in</span>
                        <div class="infor-post">
                            <a id="ux" href="#">UX Design</a>
                            
                        </div>
                        <div class="border"></div>
                        <div class="blog-share">
                            <a href="#">
                                <i class="fa fa-share-alt"></i>
                                
                            </a>
                        </div>
                    </div>
                    <div class="information1">
                        <div class="img1">
                            <a href="#"><img id="author-icon" src="<?php echo(get_template_directory_uri()); ?>/images/18-19-20-21/qqq.jpeg"></a>
                        </div>
                        <a href="#">Maria Keller</a>
                        <span>in</span>
                        <div class="infor-post">
                            <a id="ux" href="#">UX Design</a>
                        </div>
                        <div class="border"></div>
                        <div class="blog-share">
                            <a href="#">
                                <i class="fa fa-share-alt"></i>
                            </a>
                        </div>
                    </div>
                    <div class="information2">
                        <div class="img1">
                            <a href="#"><img id="author-icon" src="<?php echo(get_template_directory_uri()); ?>/images/18-19-20-21/19.1.jpeg"></a>
                        </div>
                        <a href="#">Maria Keller</a>
                        <span>in</span>
                        <div class="infor-post">
                            <a id="ux" href="#">UX Design</a>
                        </div>
                        <div class="border"></div>
                        <div class="blog-share">
                            <a href="#">
                                <i class="fa fa-share-alt"></i>
                            </a>
                        </div>
                    </div>
                    <div class="information3">
                        <div class="img1">
                            <a href="#"><img id="author-icon" src="<?php echo(get_template_directory_uri()); ?>/images/18-19-20-21/19.1.jpeg"></a>
                        </div>
                        <a href="#">Maria Keller</a>
                        <span>in</span>
                        <div class="infor-post">
                            <a id="ux" href="#">UX Design</a>
                        </div>
                        <div class="border"></div>
                        <div class="blog-share">
                            <a href="#">
                                <i class="fa fa-share-alt"></i>
                            </a>
                        </div>
                    </div>
                    <div class="information4">
                        <div class="img1">
                            <a href="#"><img id="author-icon" src="<?php echo(get_template_directory_uri()); ?>/images/18-19-20-21/qqq.jpeg"></a>
                        </div>
                        <a href="#">Maria Keller</a>
                        <span>in</span>
                        <div class="infor-post">
                            <a id="ux" href="#">UX Design</a>
                        </div>
                        <div class="border"></div>
                        <div class="blog-share">
                            <a href="#">
                                <i class="fa fa-share-alt"></i>
                            </a>
                        </div>
                    </div>
                    
                    <div class="information5">
                        <div class="img1">
                            <a href="#"><img id="author-icon" src="<?php echo(get_template_directory_uri()); ?>/images/18-19-20-21/qqq.jpeg"></a>
                        </div>
                        <a href="#">Maria Keller</a>
                        <span>in</span>
                        <div class="infor-post">
                            <a id="ux" href="#">UX Design</a>
                        </div>
                        <div class="border"></div>
                        <div class="blog-share">
                            <a href="#">
                                <i class="fa fa-share-alt"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-7">
                    <div class="mory-magin">
                    <div class="mort">
                        <div class="data">
                            <a href="#">
                                <div class="date-day1">9 </div>
                                <div class="date-month1">Aug </div>
                            </a>
                        </div>
                    <div class="post-images">
                        <a href="#">
                            <img id="hinh2" src="<?php echo(get_template_directory_uri()); ?>/images/18-19-20-21/19.2.jpg">
                        </a>
                    </div>
                    </div>
                    <div class="post-mast">
                        <h2>
                            <a class="po-ti" href="#">Every accomplishment starts with a decision to try. </a>
                        </h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisciium, placeraLorem ipsum dolor sit amet, consectetur adipiscing elit. nec vel mauris pretium, placerarci ipsum, feugiat eung elit. Nullam sed libero vel nisl pulvinar scelerisque. Donec vel mauris pretium, placerat Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam sed libero vel nisl pulvinar scelerisque. Donec vel mauris pretium, placera Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam sed libero vel nisl pulvinar scelerisque. Donec vel mauris pretium, placera Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam sed libero vel nisl pulvinar scelerisqueLorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam sed libero vel nisl pulvinar scelerisque. Donec vel mauris pretium, placeraLorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam sed libero vel nisl pulvinar scelerisque. Donec vel mauris pretium, placerarci ipsum, feugiat eu </p>
                        <span class="getdate"><i class="fa fa-calendar"><a href="#">9 August, 2017  </a></i></span>
                        
                        <a class="month" href="#">
                            
                            <span><i class="fa fa-heart"> 0 </i> </span>
                        </a>
                        <a class="year" href="#">
                            <span>
                                <i class="fa fa-comment" aria-hidden="true"> 3</i>
                            </span>
                            <span></span>
                        </a>
                    </div>
                </div>
                    <div class="mory-magin">
                    <div class="mort">
                        <div class="data1">
                            <a href="#">
                                <div class="date-day1">9 </div>
                                <div class="date-month1">Aug </div>
                            </a>
                        </div>
                    <div class="post-images">
                        <a href="#">
                            <img id="hinh2" src="<?php echo(get_template_directory_uri()); ?>/images/18-19-20-21/blog-post-2.jpg">
                        </a>
                    </div>
                    </div>
                    <div class="post-mast">
                        <h2>
                            <a class="po-ti" href="#">Every accomplishment starts with a decision to try. </a>
                        </h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam sed libero vel nisl pulvinar scelerisque. Donec vel mauris pretium, placerat sapien nec, vestibulum sapien. Nam interdum pellentesque augue id sollicitudin. Fusce eget mauris tellus. Vestibulum orci ipsum, feugiat eu </p>
                        <span class="getdate"><i class="fa fa-calendar"><a href="#">9 August, 2017  </a></i></span>
                        
                        <a class="month" href="#">
                            
                            <span><i class="fa fa-heart"> 0 </i> </span>
                        </a>
                        <a class="year" href="#">
                            <span>
                                <i class="fa fa-comment" aria-hidden="true"> 3</i>
                            </span>
                            <span></span>
                        </a>
                    </div>
                    </div>
                    <div class="mory-magin1">
                        <div id="jjj" class="post-hoder">
                        <h2>
                            <a  href="#" class="title-post">The man who use his skill to see how much he can give for a dollar, instead of how little he can give for a dollar, is bound to succeed. </a>
                        </h2>
                        <span class="horly">Henry Ford </span>
                        <div class="post-mast">
                        
                        <span class="iconfor"><i class="fa fa-quote-right"></i></span>
                    </div>
                    </div>
                    
                    </div>
                    <div class="mory-magin">
                    <div class="mort">
                        <div class="data2">
                        <a href="#">
                                <div class="date-day1">9 </div>
                                <div class="date-month1">Aug </div>
                            </a>
                        </div>
                    <div class="post-images">
                        <a href="#">
                            <img id="hinh2" src="<?php echo(get_template_directory_uri()); ?>/images/18-19-20-21/blog-post-3.jpg">
                        </a>
                    </div>
                    </div>
                    <div class="post-mast">
                        <h2>
                            <a class="po-ti" href="#">Every accomplishment starts with a decision to try. </a>
                        </h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam sed libero vel nisl pulvinar scelerisque. Donec vel mauris pretium, placerat sapien nec, vestibulum sapien. Nam interdum pellentesque augue id sollicitudin. Fusce eget mauris tellus. Vestibulum orci ipsum, feugiat eu </p>
                        <span class="getdate"><i class="fa fa-calendar"><a href="#">9 August, 2017  </a></i></span>
                        
                        <a class="month" href="#">
                            
                            <span><i class="fa fa-heart"> 0 </i> </span>
                        </a>
                        <a class="year" href="#">
                            <span>
                                <i class="fa fa-comment" aria-hidden="true"> 3</i>
                            </span>
                            <span></span>
                        </a>
                    </div>
                    </div>
                    <div class="mory-magin">
                    <div class="mort">
                        <div class="data3">
                        <a href="#">
                                <div class="date-day1">9 </div>
                                <div class="date-month1">Aug </div>
                            </a>
                        </div>
                    <div class="post-images">
                        <a href="#">
                            <img id="hinh2" src="<?php echo(get_template_directory_uri()); ?>/images/18-19-20-21/blog-post-1.jpg">
                        </a>
                    </div>
                    </div>
                    <div class="post-mast">
                        <h2>
                            <a class="po-ti" href="#">Every accomplishment starts with a decision to try. </a>
                        </h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam sed libero vel nisl pulvinar scelerisque. Donec vel mauris pretium, placerat sapien nec, vestibulum sapien. Nam interdum pellentesque augue id sollicitudin. Fusce eget mauris tellus. Vestibulum orci ipsum, feugiat eu </p>
                        <span class="getdate"><i class="fa fa-calendar"><a href="#">9 August, 2017  </a></i></span>
                        
                        <a class="month" href="#">
                            
                            <span><i class="fa fa-heart"> 0 </i> </span>
                        </a>
                        <a class="year" href="#">
                            <span>
                                <i class="fa fa-comment" aria-hidden="true"> 3</i>
                            </span>
                            <span></span>
                        </a>
                    </div>
                    </div>
                    
                    
                    
                    <div class="mory-magin1">
                        <div id="jjj" class="post-hoder">
                        <h2>
                            <a  href="#" class="title-post">The man who use his skill to see how much he can give for a dollar, instead of how little he can give for a dollar, is bound to succeed. </a>
                        </h2>
                        <div class="post-mast">
                        
                        <span class="iconfor"><i class="fa fa-quote-right"></i></span>
                    </div>
                    </div>
                    
                    </div>
                    <div class="page-blog">
                        <ul>
                            <li><a href="#">1</a></li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li><a href="#">4</a></li>
                            <li><a href="#"><span>></span></a></li>
                            <li><a href="#"><span>>></span></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="sidebar">
                            <div class="search">
                                <input type="search" value="" name="s" class="email" 
                                 placeholder="Search..." required="">
                                 <span class="icon"><i class="fa fa-search"></i></span>
                            </div>
                            <div class="category">
                                <div class="categories">
                                    <div class="s">
                                        <div class="border">
                                            <h4>Categories</h4>
                                        </div>
                                    </div>
                                    
                                </div>
                                <ul>
                                    <li class="a">
                                        <a href="#">Business</a>(5)
                                    </li>
                                    <li class="b">
                                        <a href="#">Design Trends</a>(1)
                                    </li>
                                    <li class="c">
                                        <a href="#">Lifestyle</a>(1)
                                    </li>
                                    <li class="d">
                                        <a href="#">Technology</a>(24)
                                    </li>
                                    <li class="e">
                                        <a href="#">UX Design</a>(2)
                                    </li>
                                </ul>
                                <div class="categories">
                                    <div class="s">
                                         <div class="border">
                                            <h4>Latest Nes</h4>
                                        </div>
                                    </div>
                                   
                                    <div  class="post-list">
                                            <div class="odd">
                                                <div class="item-avatar">
                                                    <a href="#" title="Green Food">
                                                        <img src="<?php echo(get_template_directory_uri()); ?>/images/18-19-20-21/18.1.jpg" alt="" />
                                                    </a>
                                                </div>
                                                <div class="item">
                                                    <div><a href="#">Don’t think big, think giant. </a></div>
                                                    <div>
                                                        <span>
                                                            <a href="">1 August, 2017 </a>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                    <div  class="post-list2">
                                            <div class="odd">
                                                <div class="item-avatar2">
                                                    <a href="#" title="Green Food">
                                                        <img src="<?php echo(get_template_directory_uri()); ?>/images/18-19-20-21/18.2.jpg" alt="" />
                                                    </a>
                                                </div>
                                                <div class="item2">
                                                    <div><a href="#">Details create the big picture. </a></div>
                                                    <div>
                                                        <span>
                                                            <a href="">2 August, 2017 </a>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                    <div  class="post-list3">
                                        <div class="odd">
                                            <div class="item-avatar3">
                                                <a href="#" title="Green Food">
                                                    <img src="<?php echo(get_template_directory_uri()); ?>/images/18-19-20-21/18.3.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="item3">
                                                <div><a href="#">Together everyone achieves more. </a></div>
                                                <div>
                                                    <span>
                                                        <a href="">
                                                            3 August, 2017 
                                                        </a>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="more-img">
                                        <div class="sidebar-image">
                        <img id="backgourd" src="<?php echo(get_template_directory_uri()); ?>/images/18-19-20-21/pages-sidebar-banner.jpg">
                             <h2 class="size">Impossible is nothing.</h2>
                        <a href="#">Learn More</a>
                    </div>
                    <div class="tag-blog">
                        <div class="tag1">
                            <h4>Tag</h4>
                        </div>
                        <div class="tag2">
                            <a href="#" class="tag-cloud1" >Branding</a>
                            <a href="#" class="tag-cloud2" >Business</a>
                            <a href="#" class="tag-cloud3" >Gadgets</a>
                            <a href="#" class="tag-cloud4" >Goals</a>
                            <a href="#" class="tag-cloud5" >Modern</a>
                            <a href="#" class="tag-cloud6" >Music &amp; Sound</a>
                            <a href="#" class="tag-cloud7" >New</a>
                            <a href="#" class="tag-cloud8" >Time Management</a>
                            <a href="#" class="tag-cloud9" >Video</a></div>
                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>    
    </div>
</div>
    