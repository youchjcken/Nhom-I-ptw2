<?php 
    /*template name:About Us*/
    
?>
<?php get_header(); ?>

<?php get_template_part('modul/12','content') ?>
<?php get_template_part('modul/13','content') ?>
<?php get_template_part('modul/14','content') ?>

<?php get_footer();?>

