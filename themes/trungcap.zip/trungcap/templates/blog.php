<?php 
    /*template name:Blog*/
    
?>
<?php get_header(); ?>
<?php get_template_part('modul/26','content') ?>
<?php get_template_part('modul/18-19-20-21','content') ?>


<?php get_footer();?>

