<?php 
    /*template name:Banner*/
    
?>
<?php get_header(); ?>
<?php get_template_part('modul/22','content') ?>
<?php get_template_part('modul/23','content') ?>


<?php get_footer();?>

