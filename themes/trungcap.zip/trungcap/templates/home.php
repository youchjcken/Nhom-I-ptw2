<?php 
    /*template name:Home*/
    
?>
<?php get_header(); ?>

<?php get_template_part('modul/2','content') ?>;

<?php get_template_part('modul/4','content') ?>;
<?php get_template_part('modul/6','content') ?>;
<?php get_template_part('modul/9','content') ?>;
<?php get_footer();?>

