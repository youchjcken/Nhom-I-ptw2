<?php 
    /*template name:Shop*/
    
?>
<?php get_header(); ?>

<?php get_template_part('modul/17','content') ?>
<?php get_template_part('modul/15','content') ?>

<?php get_footer();?>

